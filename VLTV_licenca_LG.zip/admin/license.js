// Licenças do app da LG: teste grátis por TV + ativação anual.
// Rotas públicas (a TV chama):  /lg/register  /lg/status  /lg/config  /parceiro/resolver  /lg/pix/webhook
// Rotas do painel (login):      /api/admin/devices*  /api/admin/partners*  /api/admin/payments  /api/admin/lg-stats
const crypto = require('crypto');
const express = require('express');
const db = require('./db');
const { requireAdminAuth, limitar, igual } = require('./auth');

const TRIAL_DIAS = parseInt(process.env.TRIAL_DIAS || '7', 10);
const ANO_DIAS = 365;
const VITALICIO = 4102444800;   // 01/01/2100: licença sem vencimento
const ehVitalicio = d => d.paid_until >= VITALICIO;
const DIA = 86400;
const ALFABETO = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const agoraS = () => Math.floor(Date.now() / 1000);

function segredo() {
  if (!process.env.LICENSE_SECRET || process.env.LICENSE_SECRET.length < 24) {
    throw new Error('Defina LICENSE_SECRET (24+ caracteres) no .env do admin');
  }
  return process.env.LICENSE_SECRET;
}

// Token da TV: "device_id.expira.assinatura" (HMAC). Sem guardar nada no banco.
function assinar(deviceId, validadeDias) {
  const exp = agoraS() + validadeDias * DIA;
  const base = deviceId + '.' + exp;
  const sig = crypto.createHmac('sha256', segredo()).update(base).digest('base64url');
  return base + '.' + sig;
}
function verificar(token) {
  const p = String(token || '').split('.');
  if (p.length !== 3) return null;
  const base = p[0] + '.' + p[1];
  const sig = crypto.createHmac('sha256', segredo()).update(base).digest('base64url');
  if (!igual(sig, p[2])) return null;
  if (parseInt(p[1], 10) < agoraS()) return null;
  return p[0];
}

function gerarCodigo(tabela, coluna) {
  for (;;) {
    const b = crypto.randomBytes(8);
    let c = '';
    for (let i = 0; i < 8; i++) c += ALFABETO[b[i] % ALFABETO.length];
    if (!db.prepare(`SELECT 1 FROM ${tabela} WHERE ${coluna} = ?`).get(c)) return c;
  }
}

function estadoDe(d) {
  const t = agoraS();
  if (d.blocked) return 'blocked';
  if (d.paid_until > t) return 'active';
  if (d.trial_end > t) return 'trial';
  return 'expired';
}
function resposta(d, extra) {
  const estado = estadoDe(d);
  const fim = estado === 'active' ? d.paid_until : d.trial_end;
  return Object.assign({
    estado,
    vitalicio: ehVitalicio(d),
    codigo: d.code,
    expira_em: fim,
    dias: Math.max(0, Math.ceil((fim - agoraS()) / DIA)),
    pagar_url: process.env.PAGAR_URL || 'vltvplay.tech/ativar'
  }, extra || {});
}

function limpoId(v) { return String(v || '').trim().slice(0, 80); }
function limpoMac(v) {
  const m = String(v || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  return m.length === 12 && m !== '000000000000' && m !== 'FFFFFFFFFFFF' ? m : '';
}

const pub = express.Router();

// A TV se apresenta. Se for nova, ganha o teste; se já existe, só recebe o estado atual.
pub.post('/lg/register',
  limitar('reg', 30, 3600000),
  (req, res) => {
    const deviceId = limpoId(req.body.device_id);
    const mac = limpoMac(req.body.mac);
    if (!/^(mac|uid)-[A-Za-z0-9]{8,64}$/.test(deviceId)) {
      return res.status(400).json({ error: 'device_id inválido' });
    }
    const model = limpoId(req.body.model).slice(0, 60);
    const versao = limpoId(req.body.version).slice(0, 20);
    const t = agoraS();

    let d = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(deviceId);
    // Mesmo MAC com outro device_id (app reinstalado/limpo): é a mesma TV, não ganha outro teste.
    if (!d && mac) d = db.prepare('SELECT * FROM devices WHERE mac = ? ORDER BY id LIMIT 1').get(mac);

    if (!d) {
      // Freio contra criar testes em massa: no máximo 5 TVs novas por IP por dia.
      const hoje = db.prepare('SELECT COUNT(*) n FROM devices WHERE last_ip = ? AND created_at > ?').get(req.ip, t - DIA).n;
      if (hoje >= 5) return res.status(429).json({ error: 'Limite de novos aparelhos neste endereço. Tente amanhã.' });
      db.prepare(`INSERT INTO devices (device_id, code, mac, model, app_version, created_at, trial_end, last_seen, last_ip)
                  VALUES (?,?,?,?,?,?,?,?,?)`)
        .run(deviceId, gerarCodigo('devices', 'code'), mac || null, model, versao, t, t + TRIAL_DIAS * DIA, t, req.ip);
      d = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(deviceId);
    } else {
      db.prepare('UPDATE devices SET last_seen=?, last_ip=?, model=COALESCE(NULLIF(?,\'\'),model), app_version=COALESCE(NULLIF(?,\'\'),app_version), mac=COALESCE(mac, ?) WHERE id=?')
        .run(t, req.ip, model, versao, mac || null, d.id);
      d = db.prepare('SELECT * FROM devices WHERE id = ?').get(d.id);
    }
    res.json(resposta(d, { token: assinar(d.device_id, 60) }));
  });

// A TV pergunta o estado (a cada abertura e de tempos em tempos).
pub.get('/lg/status', limitar('st', 120, 3600000), (req, res) => {
  const h = req.headers['authorization'] || '';
  const id = verificar(h.startsWith('Bearer ') ? h.slice(7) : '');
  if (!id) return res.status(401).json({ error: 'token' });
  const d = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(id);
  if (!d) return res.status(404).json({ error: 'desconhecido' });
  db.prepare('UPDATE devices SET last_seen=?, last_ip=? WHERE id=?').run(agoraS(), req.ip, d.id);
  res.json(resposta(d, { token: assinar(d.device_id, 60) }));
});

// Visual e campanhas: só chaves "lg." da tabela config (cores, logo, banners, campanhas).
pub.get('/lg/config', limitar('cfg', 120, 3600000), (req, res) => {
  const rows = db.prepare("SELECT key, value FROM config WHERE key LIKE 'lg.%'").all();
  const o = {};
  rows.forEach(r => { o[r.key.slice(3)] = r.value; });
  res.set('Cache-Control', 'public, max-age=300').json(o);
});

// Código de parceiro -> lista de DNS (mesmo contrato do servidor antigo da porta 3355).
function limpoCodigo(t) { return String(t || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
pub.get('/parceiro/resolver', limitar('par', 20, 60000), (req, res) => {
  const codigo = limpoCodigo(req.query.codigo);
  const p = codigo && db.prepare('SELECT * FROM partners WHERE code = ?').get(codigo);
  res.set('Cache-Control', 'no-store');
  if (!p) return res.status(404).json({ ok: false });
  if (!p.active) return res.status(403).json({ ok: false });
  res.json({ ok: true, nome: p.name, dns: JSON.parse(p.dns) });
});

// ----- Pix: o provedor (Mercado Pago/Efí/Asaas) chama aqui quando o pagamento cai -----
// Fica atrás de PIX_WEBHOOK_SECRET (cabeçalho x-webhook-secret ou ?s=). O adaptador do provedor
// só precisa mandar { device_code, txid, amount_cents }. Idempotente por txid.
function ativar(codigo, meses, txid, valor, provedor) {
  const d = db.prepare('SELECT * FROM devices WHERE code = ?').get(limpoCodigo(codigo));
  if (!d) return { ok: false, motivo: 'codigo' };
  const t = agoraS();
  const tx = db.transaction(() => {
    if (txid) {
      const ja = db.prepare('SELECT 1 FROM payments WHERE txid = ?').get(txid);
      if (ja) return { ok: true, repetido: true };
      db.prepare('INSERT INTO payments (device_code, txid, amount_cents, provider, created_at) VALUES (?,?,?,?,?)')
        .run(d.code, txid, valor || null, provedor || 'manual', t);
    }
    if (meses === 'vitalicio') {
      db.prepare('UPDATE devices SET paid_until = ? WHERE id = ?').run(VITALICIO, d.id);
      return { ok: true };
    }
    if (ehVitalicio(d)) return { ok: true };   // já é vitalícia: não encurta
    const base = Math.max(t, d.paid_until);
    db.prepare('UPDATE devices SET paid_until = ? WHERE id = ?').run(base + Math.round(meses * ANO_DIAS / 12) * DIA, d.id);
    return { ok: true };
  });
  return tx();
}
pub.post('/lg/pix/webhook', limitar('pix', 120, 60000), (req, res) => {
  const s = req.headers['x-webhook-secret'] || req.query.s;
  if (!process.env.PIX_WEBHOOK_SECRET || !igual(s, process.env.PIX_WEBHOOK_SECRET)) return res.status(401).json({ error: 'x' });
  const { device_code, txid, amount_cents, plano } = req.body || {};
  if (!device_code || !txid) return res.status(400).json({ error: 'dados' });
  const r = ativar(device_code, plano === 'vitalicio' ? 'vitalicio' : 12, String(txid).slice(0, 80), parseInt(amount_cents, 10) || null, 'pix');
  res.status(r.ok ? 200 : 404).json(r);
});

// ============ PAINEL (precisa de login) ============
const adm = express.Router();
adm.use(requireAdminAuth);

adm.get('/devices', (req, res) => {
  const q = String(req.query.q || '').trim();
  const lim = Math.min(parseInt(req.query.limit, 10) || 200, 1000);
  const t = agoraS();
  let sql = 'SELECT * FROM devices';
  const args = [];
  const w = [];
  if (q) { w.push('(code LIKE ? OR mac LIKE ? OR model LIKE ? OR note LIKE ? OR device_id LIKE ?)'); const l = '%' + q + '%'; args.push(l, l, l, l, l); }
  const e = req.query.estado;
  if (e === 'blocked') w.push('blocked = 1');
  else if (e === 'active') { w.push('blocked = 0 AND paid_until > ?'); args.push(t); }
  else if (e === 'trial') { w.push('blocked = 0 AND paid_until <= ? AND trial_end > ?'); args.push(t, t); }
  else if (e === 'expired') { w.push('blocked = 0 AND paid_until <= ? AND trial_end <= ?'); args.push(t, t); }
  if (w.length) sql += ' WHERE ' + w.join(' AND ');
  sql += ' ORDER BY id DESC LIMIT ?';
  args.push(lim);
  res.json(db.prepare(sql).all(...args).map(d => Object.assign({}, d, { estado: estadoDe(d) })));
});

adm.get('/lg-stats', (req, res) => {
  const t = agoraS();
  const n = (w, ...a) => db.prepare('SELECT COUNT(*) n FROM devices WHERE ' + w).get(...a).n;
  res.json({
    total: n('1=1'),
    ativos: n('blocked=0 AND paid_until > ?', t),
    teste: n('blocked=0 AND paid_until <= ? AND trial_end > ?', t, t),
    expirados: n('blocked=0 AND paid_until <= ? AND trial_end <= ?', t, t),
    bloqueados: n('blocked=1'),
    novos_24h: n('created_at > ?', t - DIA),
    pagamentos: db.prepare('SELECT COUNT(*) n FROM payments').get().n
  });
});

// Ações sobre uma TV (por id numérico ou código)
adm.patch('/devices/:ref', (req, res) => {
  const ref = req.params.ref;
  const d = /^\d+$/.test(ref) ? db.prepare('SELECT * FROM devices WHERE id=?').get(ref) : db.prepare('SELECT * FROM devices WHERE code=?').get(limpoCodigo(ref));
  if (!d) return res.status(404).json({ error: 'não encontrado' });
  const b = req.body || {};
  const t = agoraS();
  if (b.activate_lifetime) {
    ativar(d.code, 'vitalicio', 'admin-vit-' + t + '-' + d.id, null, 'manual:' + (req.admin.username || ''));
  }
  if (b.activate_months) {
    const m = Math.min(Math.max(parseFloat(b.activate_months), 0.1), 60);
    ativar(d.code, m, 'admin-' + t + '-' + d.id, null, 'manual:' + (req.admin.username || ''));
  }
  if (b.add_trial_days) {
    const dias = Math.min(Math.max(parseInt(b.add_trial_days, 10), 1), 365);
    db.prepare('UPDATE devices SET trial_end = ? WHERE id = ?').run(Math.max(t, d.trial_end) + dias * DIA, d.id);
  }
  if (b.revoke) db.prepare('UPDATE devices SET paid_until = 0, trial_end = ? WHERE id = ?').run(t - 1, d.id);
  if (b.blocked !== undefined) db.prepare('UPDATE devices SET blocked = ? WHERE id = ?').run(b.blocked ? 1 : 0, d.id);
  if (b.note !== undefined) db.prepare('UPDATE devices SET note = ? WHERE id = ?').run(String(b.note).slice(0, 200), d.id);
  const n = db.prepare('SELECT * FROM devices WHERE id=?').get(d.id);
  res.json(Object.assign({}, n, { estado: estadoDe(n) }));
});

adm.delete('/devices/:id', (req, res) => {
  db.prepare('DELETE FROM devices WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

adm.get('/payments', (req, res) => {
  res.json(db.prepare('SELECT * FROM payments ORDER BY id DESC LIMIT 300').all());
});

// ----- Parceiros -----
function limpoDns(lista) {
  const out = [];
  (Array.isArray(lista) ? lista : String(lista || '').split(/[\s,;]+/)).forEach(i => {
    let u = String(i || '').trim();
    if (!u) return;
    if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
    u = u.replace(/\/+$/, '');
    if (out.indexOf(u) === -1) out.push(u);
  });
  return out;
}
adm.get('/partners', (req, res) => {
  res.json(db.prepare('SELECT * FROM partners ORDER BY created_at DESC').all().map(p => Object.assign({}, p, { dns: JSON.parse(p.dns) })));
});
adm.post('/partners', (req, res) => {
  const nome = String((req.body || {}).name || '').trim().slice(0, 80);
  const dns = limpoDns((req.body || {}).dns);
  if (!nome || !dns.length) return res.status(400).json({ error: 'name e dns obrigatórios' });
  const code = gerarCodigo('partners', 'code');
  db.prepare('INSERT INTO partners (code, name, dns, active, created_at) VALUES (?,?,?,1,?)').run(code, nome, JSON.stringify(dns), agoraS());
  res.json({ ok: true, code });
});
adm.patch('/partners/:code', (req, res) => {
  const p = db.prepare('SELECT * FROM partners WHERE code = ?').get(limpoCodigo(req.params.code));
  if (!p) return res.status(404).json({ error: 'não encontrado' });
  const b = req.body || {};
  const nome = b.name !== undefined ? String(b.name).trim().slice(0, 80) : p.name;
  const dns = b.dns !== undefined ? limpoDns(b.dns) : JSON.parse(p.dns);
  if (!nome || !dns.length) return res.status(400).json({ error: 'dados inválidos' });
  db.prepare('UPDATE partners SET name=?, dns=?, active=? WHERE code=?').run(nome, JSON.stringify(dns), b.active === undefined ? p.active : (b.active ? 1 : 0), p.code);
  res.json({ ok: true });
});
adm.delete('/partners/:code', (req, res) => {
  db.prepare('DELETE FROM partners WHERE code = ?').run(limpoCodigo(req.params.code));
  res.json({ ok: true });
});

module.exports = { pub, adm, estadoDe };
