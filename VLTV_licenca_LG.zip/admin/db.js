const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(process.env.ADMIN_DB_PATH || path.join(__dirname, 'vltv_admin.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS trials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    list_id TEXT NOT NULL,
    list_name TEXT NOT NULL,
    device TEXT NOT NULL,
    app_label TEXT NOT NULL,
    username TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  -- ===== App da LG: licenças (todas as datas em segundos desde 1970) =====
  CREATE TABLE IF NOT EXISTS devices (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id    TEXT UNIQUE NOT NULL,   -- identidade da TV (mac-XXXX ou uid-XXXX)
    code         TEXT UNIQUE NOT NULL,   -- código curto mostrado na TV (ex: K7QM4X2P)
    mac          TEXT,
    model        TEXT,
    app_version  TEXT,
    created_at   INTEGER NOT NULL,
    trial_end    INTEGER NOT NULL,
    paid_until   INTEGER NOT NULL DEFAULT 0,
    blocked      INTEGER NOT NULL DEFAULT 0,
    note         TEXT,
    last_seen    INTEGER,
    last_ip      TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_devices_mac ON devices(mac);

  CREATE TABLE IF NOT EXISTS payments (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    device_code  TEXT NOT NULL,
    txid         TEXT UNIQUE NOT NULL,   -- idempotência: o mesmo pagamento nunca vale 2x
    amount_cents INTEGER,
    provider     TEXT,
    created_at   INTEGER NOT NULL
  );

  -- Pagamentos Pix criados no Mercado Pago e ainda não confirmados
  CREATE TABLE IF NOT EXISTS pix_pending (
    mp_id        TEXT PRIMARY KEY,
    device_code  TEXT NOT NULL,
    plano        TEXT NOT NULL,         -- 'anual' | 'vitalicio'
    amount_cents INTEGER NOT NULL,
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS partners (
    code        TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    dns         TEXT NOT NULL,           -- JSON: ["http://a.com","http://b.com"]
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  INTEGER NOT NULL
  );
`);

module.exports = db;
