// =============================================
// VLTV Play — server.js
// Backend Node.js — Gemini 3.5 Flash-Lite + TMDB
// =============================================

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');
const url   = require('url');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const TMDB_API_KEY   = process.env.TMDB_API_KEY   || '9b73f5dd15b8165b1b57419be2f29128';
const PORT           = process.env.PORT || 3000;
const STATIC_DIR     = path.join(__dirname, 'public');

// ✅ Modelo do Gemini usado no chat. O antigo "gemini-2.0-flash" foi
// desativado pelo Google em 2026 (era essa a causa do chat sempre
// responder "não foi possível processar"). Trocado pelo "gemini-3.5-flash-lite",
// a versão estável (GA) mais atual voltada para uso leve/alta frequência
// como este chat — ainda dentro do nível gratuito da API.
const GEMINI_MODEL = 'gemini-3.5-flash-lite';

// ✅ A VPS (IP de datacenter/hospedagem) estava sendo bloqueada pelo
// Google com o erro "User location is not supported for the API use",
// mesmo o Canadá sendo um país oficialmente suportado — isso é um bloqueio
// conhecido do Google contra IPs de VPS/datacenter no free tier, não um
// bloqueio real de região. A solução gratuita é rotear as chamadas por um
// proxy no Cloudflare Workers (plano free, sem cartão) em vez de chamar
// generativelanguage.googleapis.com diretamente da VPS.
const GEMINI_PROXY_HOST = 'vltv-gemini-proxy.leandro-gracas.workers.dev';

// ✅ URL do APK do VLTV Play, usada na resposta do teste automático dentro
// do chat. Precisa ficar IGUAL à variável AUTO_TEST_APK_URL do script.js —
// se trocar o link de download em um lugar, troque no outro também.
const VLTV_APK_URL = 'https://cdn.vltvplay.tech/downloads/VLTV-Play.apk';

const MIME = {
    '.html': 'text/html; charset=utf-8',
    '.css':  'text/css',
    '.js':   'application/javascript',
    '.png':  'image/png',
    '.jpg':  'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.ico':  'image/x-icon',
    '.svg':  'image/svg+xml',
    '.json': 'application/json',
    '.webp': 'image/webp',
    '.webmanifest': 'application/manifest+json',
    '.txt':  'text/plain; charset=utf-8',
    '.xml':  'application/xml; charset=utf-8',
};

const SYSTEM_INSTRUCTION = `Você é o assistente virtual oficial da VLTV Play, um serviço de IPTV premium brasileiro.
Responda SEMPRE em português do Brasil, com tom simpático, objetivo e profissional.
Nunca se identifique como IA genérica ou mencione o Google ou Gemini — você é o Assistente VLTV.

== SAUDAÇÕES ==
Se o usuário disser "bom dia", "boa tarde", "boa noite", "olá", "oi", "tudo bem", "hey" ou qualquer saudação, responda de forma amigável e pergunte como pode ajudar com o VLTV Play.

== PLANOS E PREÇOS ==
- Plano Mensal:     R$ 40/mês    | 1 dispositivo simultâneo | HD, Full HD e 4K
- Plano Trimestral: R$ 110/3 meses | todos os benefícios | grade completa de canais
- Plano Semestral:  R$ 210/6 meses | Mais Vendido | servidores dedicados | EPG | suporte prioritário
- Plano Anual:      R$ 400/ano   | máxima economia | suporte 24h | acesso Ultra Premium
- Plano Vitalício:  R$ 569 (pagamento único) | sem mensalidades | suporte VIP permanente

== TESTE GRATUITO ==
- Duração: o teste tem duração de 3 a 6 horas, dependendo do servidor.
- Como solicitar: para solicitar o teste, oriente o cliente a clicar no botão "Solicitar Teste" logo acima no site — é 100% automático, gera o acesso na hora, sem precisar esperar ninguém da equipe.
- Nunca ofereça gerar o teste você mesmo pelo chat — o chat NUNCA gera credenciais, apenas explica e direciona pro botão.
- Se o cliente já tiver clicado no botão e tiver dúvida durante o processo, oriente pelo WhatsApp.
- Se o cliente quiser continuar após o teste, basta informar qual plano tem interesse: pagando via PIX o sinal é liberado imediatamente; pagando via boleto o sinal só é liberado após a compensação bancária.

== FIDELIDADE E CANCELAMENTO ==
- NÃO há fidelidade em nenhum plano.
- O cliente pode cancelar quando quiser, sem multa ou burocracia.

== INTERNET NECESSÁRIA ==
- Sim, é necessário ter conexão com a internet para usar o IPTV.
- Recomendamos pelo menos 10 Mbps para HD e 25 Mbps para 4K.

== DISPOSITIVOS COMPATÍVEIS ==
- Celular (Android e iPhone), Smart TV (LG e Samsung), Roku TV, TV Android/TV Box/Fire Stick.
- Instale em quantos aparelhos quiser; acesso simultâneo depende do plano.

== FORMAS DE PAGAMENTO ==
- PIX: ativação IMEDIATA e automática em minutos.
- Cartão de Crédito: ativação em até 1 hora após confirmação.
- Boleto Bancário: liberação do sinal somente após a compensação bancária (baixa), geralmente até 2 dias úteis, ou imediata enviando comprovante pelo WhatsApp.

== ATIVAÇÃO ==
As credenciais são enviadas pelo WhatsApp com tutorial passo a passo para o aparelho do cliente. Toda a configuração é feita remotamente, sem necessidade de técnico ou instalação presencial.

== PROBLEMAS DE TRAVAMENTO / SINAL / ERRO ==
Se o cliente relatar que os canais, filmes ou séries estão travando, engasgando, com erro, ou não estão funcionando, oriente este passo a passo antes de qualquer outra coisa:
1. Desligue o roteador/modem de internet da tomada e aguarde cerca de 10 segundos.
2. Desligue também a TV (ou o aparelho usado — TV Box, Fire Stick, celular, etc.) e o aplicativo.
3. Ligue o roteador novamente e aguarde todas as luzes acenderem e a internet voltar a funcionar normalmente.
4. Só depois disso, ligue a TV/aparelho novamente, abra o aplicativo e teste de novo.
5. Se mesmo após esses passos o problema continuar, oriente o cliente a entrar em contato com o suporte pelo WhatsApp: (31) 99849-1711.

== INTERPRETANDO MENSAGENS CURTAS ==
- Se o usuário mandar só uma palavra ou frase curta como "teste", "teste grátis", "quero testar", trate isso diretamente como pedido de teste gratuito e responda com as informações da seção TESTE GRATUITO (duração, como funciona, o que acontece depois) — nunca responda só com uma saudação genérica tipo "Em que posso ajudar?" quando o assunto já está claro na mensagem.
- O mesmo vale para outras palavras-chave curtas: "planos"/"preço" → responda com PLANOS E PREÇOS; "fidelidade" → FIDELIDADE E CANCELAMENTO; "dispositivos"/"aparelhos" → DISPOSITIVOS COMPATÍVEIS; "pagamento"/"pix"/"boleto" → FORMAS DE PAGAMENTO; "travando"/"não funciona"/"erro"/"sem sinal"/"sem imagem" → responda com o passo a passo de PROBLEMAS DE TRAVAMENTO / SINAL / ERRO.
- Só peça mais detalhes ao cliente se a mensagem for realmente ambígua e não corresponder a nenhum tópico conhecido acima.

== SUPORTE ==
- WhatsApp direto com a equipe.
- Suporte prioritário nos planos Semestral e Anual.
- Suporte VIP permanente no plano Vitalício.

== ESTABILIDADE E QUALIDADE ==
- Servidores dedicados nos planos Semestral, Anual e Vitalício.
- Transmissão estável, sem travamentos, qualidade HD, Full HD e 4K.

== REGRAS DO ASSISTENTE ==
- Responda saudações normalmente como um atendente faria.
- Se não souber algo com certeza, oriente pelo WhatsApp.
- Respostas curtas e diretas — máximo 3 parágrafos ou lista simples.
- Nunca invente informações sobre preços ou funcionalidades.`;

function formatDateBR(isoString) {
    if (!isoString) return '';
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return '';
    const pad = n => String(n).padStart(2, '0');
    return pad(d.getUTCDate()) + '/' + pad(d.getUTCMonth() + 1) + '/' + d.getUTCFullYear() +
        ' ' + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes());
}

// Igual formatDateBR, mas pra timestamp Unix em SEGUNDOS (painel paineloffice
// devolve exp_date assim, diferente do ISO string do Wplay).
function formatUnixDateBR(epochSeconds) {
    if (!epochSeconds) return '';
    const d = new Date(epochSeconds * 1000);
    if (isNaN(d.getTime())) return '';
    const pad = n => String(n).padStart(2, '0');
    return pad(d.getUTCDate()) + '/' + pad(d.getUTCMonth() + 1) + '/' + d.getUTCFullYear() +
        ' ' + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes());
}

function sendJSON(res, status, obj) {
    res.writeHead(status, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
    });
    res.end(JSON.stringify(obj));
}

function serveStatic(res, filePath) {
    const ext = path.extname(filePath).toLowerCase();
    fs.readFile(filePath, (err, data) => {
        if (err) { res.writeHead(404); res.end('Não encontrado'); return; }
        res.writeHead(200, {
            'Content-Type': MIME[ext] || 'application/octet-stream',
            'Cache-Control': 'public, max-age=300',
        });
        res.end(data);
    });
}

function callTMDB(tmdbPath) {
    return new Promise((resolve, reject) => {
        const req = https.request({
            hostname: 'api.themoviedb.org',
            path:     tmdbPath,
            method:   'GET',
            headers:  { 'Accept': 'application/json', 'User-Agent': 'VLTVPlay/1.0' },
        }, (apiRes) => {
            let raw = '';
            apiRes.on('data', chunk => raw += chunk);
            apiRes.on('end', () => {
                try { resolve(JSON.parse(raw)); }
                catch (e) { reject(new Error('TMDB: resposta inválida')); }
            });
        });
        req.on('error', e => reject(new Error('TMDB: ' + e.message)));
        req.setTimeout(10000, () => { req.destroy(); reject(new Error('TMDB: timeout')); });
        req.end();
    });
}

// =============================================
// TESTE AUTOMÁTICO — geração de teste (2 provedores diferentes)
// =============================================
// Cada lista pode usar um provedor diferente:
//   type 'wwpanel' → painel Wplay (API própria, com chave/token, NÃO desconta
//                    crédito porque usa o endpoint /lines/test, feito só pra
//                    teste — diferente de /lines/v2 que é venda de verdade).
//   type 'sigma'   → link "chatbot" do painel Sigma (gera teste ao ser chamado).
//
// As chaves/links NUNCA podem ir para o front-end (script.js) — só o servidor
// pode chamá-los, senão qualquer pessoa que veja o código-fonte do site
// poderia gerar testes infinitos sozinha.
//
// Para adicionar a Lista 3, 4: copie um dos blocos abaixo, troque o id e os
// dados. Os "apps" definem o que aparece pro cliente em cada aparelho — se um
// aparelho não estiver listado, ele não aparece como opção pra essa lista.
const WWPANEL_API_KEY = process.env.WWPANEL_API_KEY || '';

// Lista 3 e 4 usam o painel "paineloffice" — mesma URL de API pros dois,
// só a chave (conta) muda.
const PAINELOFFICE_API_KEY_LISTA3 = process.env.PAINELOFFICE_API_KEY_LISTA3 || '';
const PAINELOFFICE_API_KEY_LISTA4 = process.env.PAINELOFFICE_API_KEY_LISTA4 || '';

// =============================================
// NOTIFICAÇÕES — Telegram + registro no admin
// =============================================
// Nenhuma dessas 4 é obrigatória: se faltar alguma, aquela notificação
// específica simplesmente não dispara (sem quebrar a geração do teste).
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const TELEGRAM_CHAT_ID   = process.env.TELEGRAM_CHAT_ID   || '';
const SITE_NOTIFY_KEY    = process.env.SITE_NOTIFY_KEY    || '';
// URL interna do vltv-admin. Como os dois rodam na mesma VPS, chama direto
// por localhost (mais rápido e não depende do Cloudflare/nginx do domínio
// admin.vltvplay.tech). Ajuste a porta se o vltv-admin usar outra.
const ADMIN_TRIALS_URL   = process.env.ADMIN_TRIALS_URL   || 'http://localhost:3001/api/admin/trials';

const TRIAL_LISTS = {
    lista1: {
        name: 'VLTV Play',
        type: 'wwpanel',
        wwpanel: {
            baseUrl:        'https://mcapi.knewcms.com:2087/lines/test',
            testDuration:   3, // horas
            package_iptv:   30,
            package_p2p:    '64399dca5ea59e8a1de2b083',
            krator_package: '1',
            notes:          'Cliente teste para avaliação (site)',
        },
        apps: {
            android:  { label: 'VLTV Play', kind: 'vltv-app' },
            smarttv:  { label: 'Kplay',     kind: 'simple-app' },
            roku:     { label: 'Kplay',     kind: 'simple-app' },
            // iPhone usa o app XCloud Mobile (App Store), login por
            // Provider + usuário/senha — não por servidor.
            iphone:   { label: 'XCloud Mobile', kind: 'provider-app', provider: 'warez' },
            // TV Android usa IBO Revenda — usuário/senha automáticos, mas o
            // cliente precisa mandar o código MAC pelo WhatsApp pra ativar.
            androidtv: { label: 'IBO Revenda', kind: 'mac-activation' },
        },
    },
    lista2: {
        name: 'VLTV+',
        type: 'sigma',
        chatbotUrl: 'https://cybertrontv.sigmab.pro/api/chatbot/XKjLMoxW04/rlKWO3Wzo7',
        apps: {
            android:  { label: 'VLTV Play', kind: 'vltv-app' },
            // PlaySim ativa por CÓDIGO (não por servidor/DNS) — o cliente
            // escolhe um dos dois códigos ao abrir o app.
            smarttv:  { label: 'PlaySim',   kind: 'code-app', codes: ['927683', '827164'] },
            roku:     { label: 'PlaySim',   kind: 'code-app', codes: ['927683', '827164'] },
            androidtv: { label: 'IBO Revenda', kind: 'mac-activation' },
        },
    },
    lista3: {
        name: 'VLTV\'S',
        type: 'paineloffice',
        paineloffice: {
            baseUrl:   'https://api-new.paineloffice.click/iptv',
            apiKey:    PAINELOFFICE_API_KEY_LISTA3,
            packageId: '26',
            screen:    '1',
            notes:     'Cliente teste para avaliação (site)',
        },
        apps: {
            android:  { label: 'VLTV Play',  kind: 'vltv-app' },
            // Max Player/Brasil IPTV não mostram servidor pro cliente — ele
            // baixa o app e ativa falando com a equipe pelo WhatsApp.
            smarttv:  { label: 'Max Player', kind: 'manual-activation' },
            roku:     { label: 'Max Player', kind: 'manual-activation' },
            androidtv: { label: 'IBO Revenda', kind: 'mac-activation' },
        },
    },
    lista4: {
        name: 'VLTV PLUS',
        type: 'paineloffice',
        paineloffice: {
            baseUrl:   'https://api-new.paineloffice.click/iptv',
            apiKey:    PAINELOFFICE_API_KEY_LISTA4,
            packageId: '26',
            screen:    '1',
            notes:     'Cliente teste para avaliação (site)',
        },
        apps: {
            android:  { label: 'VLTV Play',   kind: 'vltv-app' },
            smarttv:  { label: 'Brasil IPTV', kind: 'manual-activation' },
            roku:     { label: 'Brasil IPTV', kind: 'manual-activation' },
            iphone:   { label: 'XCloud Mobile', kind: 'provider-app', provider: 'rushplay' },
            androidtv: { label: 'IBO Revenda', kind: 'mac-activation' },
        },
    },
};

// =============================================
// TESTE AUTOMÁTICO DO APP — versão sem tela/escolha (1ª abertura do app)
// =============================================
// Cada app Android compilado usa APENAS UMA lista fixa (constante
// LISTA_TESTE dentro do próprio app, em LoginActivity.kt) — este endpoint
// só existe pra reaproveitar a MESMA lógica de geração (generateTrial) já
// usada pelo botão "Solicitar Teste" do site, sem tutorial nem escolha de
// aparelho/lista, e sempre para o app Android ('vltv-app').
//
// Só listas com app Android disponível podem ser usadas aqui — hoje
// lista1 e lista2 (ambas com apps.android.kind === 'vltv-app'). Se um dia
// lista3/4 ganharem app Android, basta incluir o id aqui.
const ALLOWED_APP_TRIAL_LISTS = ['lista1', 'lista2'];

// ✅ NOVO: aparelhos do próprio dono/desenvolvedor. Um deviceId nesta lista
// SEMPRE recebe um teste novo — não entra no controle de "já recebeu teste
// pra este aparelho" nem no limite por IP, e não fica salvo em
// app-trial-devices.json. Existe só pra você poder testar o app à vontade
// sem precisar mexer na VPS toda hora.
const DEV_DEVICE_IDS = [
    '96036a74e924a387', // celular do Léo
];

// Arquivo local (na própria VPS) que guarda, por lista, quais ANDROID_ID já
// receberam um teste — evita que desinstalar/reinstalar o app gere um teste
// novo a cada vez. Fica FORA da pasta "public" (não é servido pro navegador)
// e não precisa de nenhum banco de dados extra.
const APP_TRIAL_STORE_PATH = path.join(__dirname, 'app-trial-devices.json');

function lerAppTrialStore() {
    try {
        const raw = fs.readFileSync(APP_TRIAL_STORE_PATH, 'utf8');
        return JSON.parse(raw);
    } catch (e) {
        return {}; // arquivo ainda não existe ou está vazio/corrompido — começa do zero
    }
}

function salvarAppTrialStore(store) {
    try {
        fs.writeFileSync(APP_TRIAL_STORE_PATH, JSON.stringify(store, null, 2));
    } catch (e) {
        console.error('[app-auto-trial] Erro ao salvar app-trial-devices.json:', e.message);
    }
}

// Pega o IP real do cliente mesmo atrás do Cloudflare/proxy reverso.
function getClientIp(req) {
    const forwarded = req.headers['x-forwarded-for'];
    if (forwarded) return forwarded.split(',')[0].trim();
    return req.socket.remoteAddress || '';
}

// Limite simples por IP: no máximo 5 aparelhos novos por IP a cada 24h,
// pra dificultar um abuso em massa mesmo trocando de ANDROID_ID.
const APP_TRIAL_MAX_POR_IP_24H = 5;

function ipExcedeuLimite(store, listId, ip) {
    const registros = Object.values(store[listId] || {});
    const agora = Date.now();
    const recentesDoIp = registros.filter(r =>
        r.ip === ip && (agora - (r.createdAt || 0)) < 24 * 60 * 60 * 1000
    );
    return recentesDoIp.length >= APP_TRIAL_MAX_POR_IP_24H;
}

function callSigmaTrial(chatbotUrl) {
    return new Promise((resolve, reject) => {
        let target;
        try { target = new URL(chatbotUrl); }
        catch (e) { return reject(new Error('Sigma: URL inválida')); }

        const body = Buffer.from('{}');
        const req = https.request({
            hostname: target.hostname,
            path:     target.pathname + target.search,
            method:   'POST',
            headers:  {
                'Content-Type':   'application/json',
                'Content-Length': body.length,
            },
        }, (apiRes) => {
            let raw = '';
            apiRes.on('data', chunk => raw += chunk);
            apiRes.on('end', () => {
                try { resolve({ status: apiRes.statusCode, data: JSON.parse(raw) }); }
                catch (e) { reject(new Error('Sigma: resposta inválida')); }
            });
        });
        req.on('error', e => reject(new Error('Sigma: ' + e.message)));
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Sigma: timeout')); });
        req.write(body);
        req.end();
    });
}

function callWwpanelTrial(cfg) {
    return new Promise((resolve, reject) => {
        if (!WWPANEL_API_KEY) return reject(new Error('Wwpanel: WWPANEL_API_KEY não configurada'));
        let target;
        try { target = new URL(cfg.baseUrl); }
        catch (e) { return reject(new Error('Wwpanel: URL inválida')); }

        const bodyObj = {
            testDuration:   cfg.testDuration,
            package_iptv:   cfg.package_iptv,
            package_p2p:    cfg.package_p2p,
            krator_package: cfg.krator_package,
            notes:          cfg.notes,
        };
        const body = Buffer.from(JSON.stringify(bodyObj));

        const req = https.request({
            hostname: target.hostname,
            port:     target.port || 443,
            path:     target.pathname + target.search,
            method:   'POST',
            headers:  {
                'Content-Type':   'application/json',
                'Content-Length': body.length,
                'Authorization':  'Bearer ' + WWPANEL_API_KEY,
            },
        }, (apiRes) => {
            let raw = '';
            apiRes.on('data', chunk => raw += chunk);
            apiRes.on('end', () => {
                try { resolve({ status: apiRes.statusCode, data: JSON.parse(raw) }); }
                catch (e) { reject(new Error('Wwpanel: resposta inválida')); }
            });
        });
        req.on('error', e => reject(new Error('Wwpanel: ' + e.message)));
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Wwpanel: timeout')); });
        req.write(body);
        req.end();
    });
}

function callPaineloficeTrial(cfg) {
    return new Promise((resolve, reject) => {
        if (!cfg.apiKey) return reject(new Error('Paineloffice: chave de API não configurada'));
        let target;
        try { target = new URL(cfg.baseUrl); }
        catch (e) { return reject(new Error('Paineloffice: URL inválida')); }

        const bodyObj = {
            isTrial:   true,
            packageId: cfg.packageId,
            screen:    cfg.screen,
            notes:     cfg.notes,
        };
        const body = Buffer.from(JSON.stringify(bodyObj));

        const req = https.request({
            hostname: target.hostname,
            port:     target.port || 443,
            path:     target.pathname + target.search,
            method:   'POST',
            headers:  {
                'Content-Type':   'application/json',
                'Content-Length': body.length,
                'Authorization':  'Bearer ' + cfg.apiKey,
            },
        }, (apiRes) => {
            let raw = '';
            apiRes.on('data', chunk => raw += chunk);
            apiRes.on('end', () => {
                try { resolve({ status: apiRes.statusCode, data: JSON.parse(raw) }); }
                catch (e) { reject(new Error('Paineloffice: resposta inválida')); }
            });
        });
        req.on('error', e => reject(new Error('Paineloffice: ' + e.message)));
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Paineloffice: timeout')); });
        req.write(body);
        req.end();
    });
}

// Chama o provedor certo (wwpanel, sigma ou paineloffice) e devolve um
// objeto já normalizado, igual pros três casos, pra quem chamar não
// precisar saber qual provedor está por trás.
async function generateTrial(list) {
    if (list.type === 'wwpanel') {
        const result = await callWwpanelTrial(list.wwpanel);
        if (result.status !== 200 && result.status !== 201) {
            throw new Error('Wwpanel falhou: ' + JSON.stringify(result.data));
        }
        const d = result.data;
        return {
            username:  d.username,
            password:  d.password,
            dns:       '', // Wplay não usa DNS — login só com usuário/senha no app
            expiresAt: formatDateBR(d.exp_date),
            m3u:       '',
        };
    }

    if (list.type === 'paineloffice') {
        const result = await callPaineloficeTrial(list.paineloffice);
        if ((result.status !== 200 && result.status !== 201) || !result.data || !result.data.userIptv) {
            throw new Error('Paineloffice falhou: ' + JSON.stringify(result.data));
        }
        const u    = result.data.userIptv;
        const urls = result.data.urls || {};
        let dnsClean = '';
        try { if (urls.mpets) dnsClean = new URL(urls.mpets).origin; } catch (e) { /* ignora */ }
        return {
            username:  u.username,
            password:  u.password,
            dns:       dnsClean,
            expiresAt: formatUnixDateBR(u.exp_date),
            m3u:       urls.mpets || '',
        };
    }

    const result = await callSigmaTrial(list.chatbotUrl);
    if (result.status !== 200 || !result.data || !result.data.username) {
        throw new Error('Sigma falhou: ' + JSON.stringify(result.data));
    }
    const d = result.data;
    const dnsClean = String(d.dns || '').replace(/\/+$/, '');
    return {
        username:  d.username,
        password:  d.password,
        dns:       dnsClean,
        expiresAt: d.expiresAtFormatted || d.expiresAt || '',
        m3u:       dnsClean + '/get.php?username=' + encodeURIComponent(d.username) + '&password=' + encodeURIComponent(d.password) + '&type=m3u_plus&output=mpegts',
    };
}

// Manda uma mensagem pro Telegram avisando que um teste foi gerado.
// "Fire and forget": nunca deixa a geração do teste falhar por causa disso.
function notifyTelegram(text) {
    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) return;
    const body = Buffer.from(JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text,
        parse_mode: 'HTML',
    }));
    const req = https.request({
        hostname: 'api.telegram.org',
        path:     '/bot' + TELEGRAM_BOT_TOKEN + '/sendMessage',
        method:   'POST',
        headers:  { 'Content-Type': 'application/json', 'Content-Length': body.length },
    }, (apiRes) => { apiRes.on('data', () => {}); });
    req.on('error', e => console.error('[telegram] falhou:', e.message));
    req.write(body);
    req.end();
}

// Registra o teste no histórico do vltv-admin. Também "fire and forget".
function notifyAdminPanel(entry) {
    if (!SITE_NOTIFY_KEY) return;
    let target;
    try { target = new URL(ADMIN_TRIALS_URL); }
    catch (e) { return; }
    const body = Buffer.from(JSON.stringify(entry));
    const mod = target.protocol === 'https:' ? https : http;
    const req = mod.request({
        hostname: target.hostname,
        port:     target.port || (target.protocol === 'https:' ? 443 : 80),
        path:     target.pathname,
        method:   'POST',
        headers:  {
            'Content-Type':   'application/json',
            'Content-Length': body.length,
            'x-site-key':     SITE_NOTIFY_KEY,
        },
    }, (apiRes) => { apiRes.on('data', () => {}); });
    req.on('error', e => console.error('[admin-panel] falhou:', e.message));
    req.write(body);
    req.end();
}

// Chama as duas notificações de uma vez, a partir dos dados de um teste
// recém-gerado.
// ✅ NOVO parâmetro "origin": 'site' (padrão, comportamento de sempre) ou
// 'app' — usado pelo teste automático da 1ª abertura do app (sem tela,
// sem tutorial). Só muda o texto da notificação; o resto (Telegram +
// painel admin) continua idêntico nos dois casos.
function notifyTrialGenerated(list, listId, appInfo, device, trial, origin = 'site') {
    const deviceLabels = { android: 'Celular/TV Box', smarttv: 'Smart TV', roku: 'Roku TV', iphone: 'iPhone', androidtv: 'TV Android' };
    const deviceLabel = deviceLabels[device] || device;
    const origemLabel = origin === 'app' ? 'pelo app' : 'no site';

    notifyTelegram(
        '⚡ <b>Novo teste gerado ' + origemLabel + '!</b>\n\n' +
        '📋 Lista: <b>' + list.name + '</b>\n' +
        '📱 Aparelho: ' + deviceLabel + ' (' + appInfo.label + ')\n' +
        '👤 Usuário: <code>' + trial.username + '</code>\n' +
        '🕐 ' + new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })
    );

    notifyAdminPanel({
        listId,
        listName: list.name,
        device,
        appLabel: appInfo.label,
        username: trial.username,
        origin,
    });
}

function callGemini(history) {
    return new Promise((resolve, reject) => {
        // Injeta a instrução de sistema como primeira mensagem do histórico
        // (mesmo formato já testado e funcionando antes da migração de modelo).
        const contentsWithSystem = [
            { role: 'user',  parts: [{ text: SYSTEM_INSTRUCTION }] },
            { role: 'model', parts: [{ text: 'Entendido! Sou o Assistente VLTV, pronto para ajudar.' }] },
            ...history
        ];
        const bodyObj = {
            contents: contentsWithSystem,
            generationConfig: {
                maxOutputTokens: 1000,
            },
        };
        const body = JSON.stringify(bodyObj);

        const req = https.request({
            // ✅ Chama o proxy no Cloudflare Workers em vez de
            // generativelanguage.googleapis.com diretamente. Isso evita o
            // bloqueio "User location is not supported" que a Google aplica
            // a IPs de VPS/datacenter, sem precisar habilitar faturamento.
            hostname: GEMINI_PROXY_HOST,
            // ✅ Endpoint v1beta (padrão atual do Google para os modelos 3.x)
            // + modelo GEMINI_MODEL definido no topo do arquivo.
            path:     `/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
            method:   'POST',
            headers:  {
                'Content-Type':   'application/json',
                'Content-Length': Buffer.byteLength(body),
            },
        }, (apiRes) => {
            let raw = '';
            apiRes.on('data', chunk => raw += chunk);
            apiRes.on('end', () => {
                console.log('[Gemini] HTTP Status:', apiRes.statusCode);
                try {
                    const parsed = JSON.parse(raw);
                    if (parsed.error) console.error('[Gemini] Erro:', JSON.stringify(parsed.error));
                    resolve({ data: parsed, status: apiRes.statusCode });
                } catch (e) {
                    console.error('[Gemini] JSON inválido:', raw.slice(0, 300));
                    reject(new Error('Gemini: resposta inválida'));
                }
            });
        });

        req.on('error', e => { console.error('[Gemini] Conexão:', e.message); reject(e); });
        req.setTimeout(15000, () => { req.destroy(); reject(new Error('Gemini: timeout')); });
        req.write(body);
        req.end();
    });
}

async function fetchNowPlayingFiltered(page) {
    page = page || 1;
    const today    = new Date().toISOString().split('T')[0];
    const past60   = new Date();
    past60.setDate(past60.getDate() - 60);
    const past60Str = past60.toISOString().split('T')[0];
    return callTMDB(
        `/3/discover/movie?api_key=${TMDB_API_KEY}&language=pt-BR` +
        `&sort_by=release_date.desc` +
        `&primary_release_date.gte=${past60Str}` +
        `&primary_release_date.lte=${today}` +
        `&with_release_type=3|2&page=${page}`
    );
}

async function fetchUpcomingFiltered() {
    const today = new Date().toISOString().split('T')[0];
    let all = [];
    for (let page = 1; page <= 3; page++) {
        try {
            const data = await callTMDB(
                `/3/discover/movie?api_key=${TMDB_API_KEY}&language=pt-BR` +
                `&sort_by=release_date.asc&primary_release_date.gte=${today}` +
                `&with_release_type=3|2&page=${page}`
            );
            if (data.results && data.results.length) all = all.concat(data.results);
        } catch (e) { console.error('[upcoming] p' + page + ':', e.message); }
    }
    const seen = new Set();
    return all
        .filter(m => {
            if (!m.release_date || m.release_date < today || !m.poster_path || seen.has(m.id)) return false;
            seen.add(m.id); return true;
        })
        .sort((a, b) => a.release_date.localeCompare(b.release_date))
        .slice(0, 20);
}

const server = http.createServer(async (req, res) => {
    const parsed  = url.parse(req.url, true);
    const reqPath = parsed.pathname;

    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin':  '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
        });
        res.end();
        return;
    }

    if (reqPath === '/api/nowplaying' && req.method === 'GET') {
        try {
            sendJSON(res, 200, await fetchNowPlayingFiltered(parseInt(parsed.query.page || '1', 10)));
        } catch (err) {
            console.error('[nowplaying]', err.message);
            sendJSON(res, 500, { error: 'Erro ao buscar filmes em cartaz' });
        }
        return;
    }

    if (reqPath === '/api/upcoming' && req.method === 'GET') {
        try {
            sendJSON(res, 200, { results: await fetchUpcomingFiltered() });
        } catch (err) {
            console.error('[upcoming]', err.message);
            sendJSON(res, 500, { error: 'Erro ao buscar lançamentos' });
        }
        return;
    }

    if (reqPath === '/api/tmdb' && req.method === 'GET') {
        const endpoint = parsed.query.endpoint || '';
        if (!endpoint) return sendJSON(res, 400, { error: 'endpoint obrigatório' });
        const sep = endpoint.includes('?') ? '&' : '?';
        try {
            sendJSON(res, 200, await callTMDB(`/3/${endpoint}${sep}api_key=${TMDB_API_KEY}`));
        } catch (err) {
            console.error('[tmdb]', err.message);
            sendJSON(res, 500, { error: 'Erro TMDB' });
        }
        return;
    }

    // ── Teste automático: lista de listas/aparelhos disponíveis ─────────────
    if (reqPath === '/api/trial-lists' && req.method === 'GET') {
        const out = Object.keys(TRIAL_LISTS).map(id => ({
            id,
            name: TRIAL_LISTS[id].name,
            devices: Object.keys(TRIAL_LISTS[id].apps).map(dev => ({
                device: dev,
                appLabel: TRIAL_LISTS[id].apps[dev].label,
            })),
        }));
        sendJSON(res, 200, { lists: out });
        return;
    }

    // ── Teste automático: gera o teste de verdade (botão do site) ───────────
    if (reqPath === '/api/trial-generate' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', async () => {
            try {
                const { listId, device } = JSON.parse(body || '{}');
                const list = TRIAL_LISTS[listId];
                if (!list) return sendJSON(res, 400, { error: 'Lista inválida.' });
                const appInfo = list.apps[device];
                if (!appInfo) return sendJSON(res, 400, { error: 'Aparelho não disponível para essa lista.' });

                let out;
                try {
                    out = await generateTrial(list);
                } catch (err) {
                    console.error('[trial]', err.message);
                    return sendJSON(res, 502, { error: 'Não foi possível gerar o teste agora. Tente novamente em instantes ou fale pelo WhatsApp.' });
                }

                if (!out.username || !out.password) {
                    return sendJSON(res, 502, { error: 'Não foi possível gerar o teste agora. Tente novamente em instantes ou fale pelo WhatsApp.' });
                }

                notifyTrialGenerated(list, listId, appInfo, device, out);

                sendJSON(res, 200, Object.assign(out, {
                    appLabel: appInfo.label,
                    appKind:  appInfo.kind,
                    appCodes: appInfo.codes || null,
                    appProvider: appInfo.provider || null,
                }));
            } catch (err) {
                console.error('[trial] Erro:', err.message);
                sendJSON(res, 500, { error: 'Erro ao gerar teste.' });
            }
        });
        return;
    }

    // ── Teste automático do APP: 1ª abertura, sem tela/escolha ──────────────
    // Chamado pela LoginActivity.kt quando o app abre sem login salvo.
    // Body esperado: { listId: 'lista1' | 'lista2', deviceId: '<ANDROID_ID>' }
    if (reqPath === '/api/app-auto-trial' && req.method === 'POST') {
        sendJSON(res, 410, { error: 'Desativado: teste automático agora é por licença do app.' }); return;
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', async () => {
            try {
                const { listId, deviceId } = JSON.parse(body || '{}');

                if (!ALLOWED_APP_TRIAL_LISTS.includes(listId)) {
                    return sendJSON(res, 400, { error: 'Lista inválida para teste automático do app.' });
                }
                if (!deviceId || typeof deviceId !== 'string' || deviceId.length < 8 || deviceId.length > 128) {
                    return sendJSON(res, 400, { error: 'Identificador de aparelho inválido.' });
                }

                const list = TRIAL_LISTS[listId];
                const appInfo = list.apps.android;
                const ip = getClientIp(req);
                const isDevDevice = DEV_DEVICE_IDS.includes(deviceId);

                const store = lerAppTrialStore();
                if (!store[listId]) store[listId] = {};

                // ✅ Aparelho de dono: pula direto pra geração de um teste
                // novo, ignorando reuso e limite de IP.
                if (!isDevDevice) {
                    // ✅ Já existe teste pra este ANDROID_ID nesta lista — devolve
                    // o MESMO usuário/senha de novo (idempotente), em vez de gerar
                    // um teste novo. Cobre reinstalação do app no mesmo aparelho.
                    const existente = store[listId][deviceId];
                    if (existente) {
                        return sendJSON(res, 200, {
                            username:  existente.username,
                            password:  existente.password,
                            expiresAt: existente.expiresAt,
                            reused:    true,
                        });
                    }

                    if (ipExcedeuLimite(store, listId, ip)) {
                        return sendJSON(res, 429, { error: 'Limite de testes automáticos atingido para esta rede. Tente novamente mais tarde.' });
                    }
                }

                let out;
                try {
                    out = await generateTrial(list);
                } catch (err) {
                    console.error('[app-auto-trial]', err.message);
                    return sendJSON(res, 502, { error: 'Não foi possível gerar o teste agora.' });
                }

                if (!out.username || !out.password) {
                    return sendJSON(res, 502, { error: 'Não foi possível gerar o teste agora.' });
                }

                // ✅ Aparelho de dono nunca é gravado no arquivo de controle —
                // assim ele nunca "usa" o próprio slot e sempre pode pedir de novo.
                if (!isDevDevice) {
                    store[listId][deviceId] = {
                        username:  out.username,
                        password:  out.password,
                        expiresAt: out.expiresAt,
                        ip,
                        createdAt: Date.now(),
                    };
                    salvarAppTrialStore(store);
                }

                notifyTrialGenerated(list, listId, appInfo, 'android', out, 'app');

                sendJSON(res, 200, {
                    username:  out.username,
                    password:  out.password,
                    expiresAt: out.expiresAt,
                    reused:    false,
                });
            } catch (err) {
                console.error('[app-auto-trial] Erro:', err.message);
                sendJSON(res, 500, { error: 'Erro ao gerar teste automático.' });
            }
        });
        return;
    }

    if (reqPath === '/api/chat' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', async () => {
            try {
                const { history } = JSON.parse(body);
                if (!Array.isArray(history) || !history.length) {
                    return sendJSON(res, 400, { error: 'history inválido' });
                }

                if (!GEMINI_API_KEY) {
                    console.error('[chat] GEMINI_API_KEY não configurada!');
                    return sendJSON(res, 200, { reply: 'Assistente indisponível no momento. Fale pelo WhatsApp! 💬' });
                }
                console.log('[chat] Chamando ' + GEMINI_MODEL + ' via proxy (v1beta)...');
                const result = await callGemini(history);
                if (result.status !== 200 || result.data.error) {
                    console.error('[chat] Falhou:', JSON.stringify(result.data.error || {}));
                    return sendJSON(res, 200, { reply: 'Não consigo processar agora. Fale pelo WhatsApp! 💬' });
                }
                const reply = result.data?.candidates?.[0]?.content?.parts?.[0]?.text || 'Pode repetir?';
                console.log('[chat] ✓ Resposta OK');
                sendJSON(res, 200, { reply });
            } catch (err) {
                console.error('[chat]', err.message);
                sendJSON(res, 500, { error: 'Erro interno' });
            }
        });
        return;
    }

    // ── OG Image PNG (preview WhatsApp/redes sociais) ──────────────────────
    if (reqPath === '/og-image.jpg' || reqPath === '/og-image.png') {
        var ogPngPath = path.join(__dirname, 'og-image.png');
        if (fs.existsSync(ogPngPath)) {
            res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=3600' });
            fs.createReadStream(ogPngPath).pipe(res);
            return;
        }
        var ogSvgPath = path.join(__dirname, 'og-image.svg');
        if (fs.existsSync(ogSvgPath)) {
            res.writeHead(200, { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=3600' });
            fs.createReadStream(ogSvgPath).pipe(res);
            return;
        }
        res.writeHead(404); res.end('og-image not found');
        return;
    }

    // ── Keep-alive ping ──────────────────────────────────────────────────────
    if (reqPath === '/ping') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('pong');
        return;
    }

    let filePath = path.join(STATIC_DIR, reqPath === '/' ? 'index.html' : reqPath);
    if (!filePath.startsWith(STATIC_DIR)) { res.writeHead(403); res.end('Proibido'); return; }
    serveStatic(res, filePath);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('╔══════════════════════════════════════════╗');
    console.log('║        VLTV Play — Servidor Online       ║');
    console.log('╚══════════════════════════════════════════╝');
    console.log('🌐  URL:      http://0.0.0.0:' + PORT);
    console.log('🔑  Gemini:  ', GEMINI_API_KEY ? '✅ OK — ' + GEMINI_MODEL + ' via proxy ' + GEMINI_PROXY_HOST : '❌ NÃO CONFIGURADA — adicione GEMINI_API_KEY');
    console.log('🎬  TMDB:    ✅ OK');
    console.log('🧪  Wwpanel: ', WWPANEL_API_KEY ? '✅ OK — Lista 1 (VLTV Play) pronta' : '❌ NÃO CONFIGURADA — adicione WWPANEL_API_KEY (Lista 1 não vai funcionar)');
    console.log('🧪  Paineloffice L3:', PAINELOFFICE_API_KEY_LISTA3 ? '✅ OK — Lista 3 (VLTV\'S) pronta' : '❌ NÃO CONFIGURADA — adicione PAINELOFFICE_API_KEY_LISTA3 (Lista 3 não vai funcionar)');
    console.log('🧪  Paineloffice L4:', PAINELOFFICE_API_KEY_LISTA4 ? '✅ OK — Lista 4 (VLTV PLUS) pronta' : '❌ NÃO CONFIGURADA — adicione PAINELOFFICE_API_KEY_LISTA4 (Lista 4 não vai funcionar)');
    console.log('🔔  Telegram: ', (TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) ? '✅ OK — vai notificar' : '⚠️  desativado — configure TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID');
    console.log('📊  Admin log:', SITE_NOTIFY_KEY ? '✅ OK — vai registrar em ' + ADMIN_TRIALS_URL : '⚠️  desativado — configure SITE_NOTIFY_KEY');
    console.log('');

    // ── Keep-alive: auto-ping a cada 10 minutos ──
    var SITE_URL = process.env.RENDER_EXTERNAL_URL || ('http://localhost:' + PORT);
    setInterval(function() {
        var mod = SITE_URL.startsWith('https') ? https : http;
        mod.get(SITE_URL + '/ping', function(pingRes) {
            console.log('[keep-alive] ping ' + new Date().toLocaleTimeString('pt-BR') + ' → ' + pingRes.statusCode);
        }).on('error', function(e) {
            console.warn('[keep-alive] erro:', e.message);
        });
    }, 10 * 60 * 1000); // 10 minutos
});
