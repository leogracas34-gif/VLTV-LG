const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Comparação que não vaza (pelo tempo) quantas letras acertou.
function igual(a, b) {
  const x = crypto.createHash('sha256').update(String(a || '')).digest();
  const y = crypto.createHash('sha256').update(String(b || '')).digest();
  return crypto.timingSafeEqual(x, y);
}

function requireAdminAuth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token ausente' });
  }
  try {
    req.admin = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido ou expirado' });
  }
}

function requireAppKey(req, res, next) {
  if (!process.env.APP_API_KEY || !igual(req.headers['x-api-key'], process.env.APP_API_KEY)) {
    return res.status(401).json({ error: 'Chave de app inválida' });
  }
  next();
}

function requireSiteKey(req, res, next) {
  if (!process.env.SITE_NOTIFY_KEY || !igual(req.headers['x-site-key'], process.env.SITE_NOTIFY_KEY)) {
    return res.status(401).json({ error: 'Chave inválida' });
  }
  next();
}

// Limite simples por IP (memória). limitar('nome', máx, janelaMs)
const baldes = new Map();
function limitar(nome, max, janelaMs, chaveExtra) {
  return (req, res, next) => {
    const chave = nome + '|' + req.ip + '|' + (chaveExtra ? chaveExtra(req) : '');
    const agora = Date.now();
    let b = baldes.get(chave);
    if (!b || agora - b.inicio > janelaMs) { b = { inicio: agora, total: 0 }; baldes.set(chave, b); }
    b.total++;
    if (b.total > max) {
      res.set('Retry-After', String(Math.ceil((b.inicio + janelaMs - agora) / 1000)));
      return res.status(429).json({ error: 'Muitas tentativas. Aguarde um pouco.' });
    }
    next();
  };
}
setInterval(() => {
  const agora = Date.now();
  for (const [k, b] of baldes) { if (agora - b.inicio > 3600000) baldes.delete(k); }
}, 600000).unref();

module.exports = { requireAdminAuth, requireAppKey, requireSiteKey, limitar, igual };
