require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');
const { requireAdminAuth, requireAppKey, requireSiteKey, limitar } = require('./auth');
const license = require('./license');

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 24) {
  console.warn('[aviso] JWT_SECRET curto/ausente — troque por um texto aleatório de 32+ caracteres.');
  if (!process.env.JWT_SECRET) process.exit(1);
}
if (!process.env.LICENSE_SECRET || process.env.LICENSE_SECRET.length < 24) {
  console.error('Defina LICENSE_SECRET (24+ caracteres) no .env'); process.exit(1);
}

const app = express();
app.set('trust proxy', 'loopback');       // atrás do nginx: req.ip = IP real do cliente
app.use(express.json({ limit: '50kb' }));
// CORS só nas rotas que a TV/app usam. O painel é da mesma origem e não precisa.
app.use(['/lg', '/parceiro'], cors());
app.use(license.pub);
app.use(express.static(require('path').join(__dirname, 'public')));

// ---------- LOGIN DO PAINEL ----------
app.post('/api/admin/login', limitar('login', 8, 900000), (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Usuário e senha obrigatórios' });
  }

  const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
  if (!admin) {
    return res.status(401).json({ error: 'Usuário ou senha inválidos' });
  }

  const valid = bcrypt.compareSync(password, admin.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Usuário ou senha inválidos' });
  }

  const token = jwt.sign(
    { id: admin.id, username: admin.username },
    process.env.JWT_SECRET,
    { expiresIn: '12h' }
  );

  res.json({ token, username: admin.username });
});

// ---------- ROTAS DO PAINEL (protegidas por login) ----------

// Listar todas as configs
app.get('/api/admin/config', requireAdminAuth, (req, res) => {
  const rows = db.prepare('SELECT key, value, updated_at FROM config').all();
  res.json(rows);
});

// Criar ou atualizar uma config
app.put('/api/admin/config/:key', requireAdminAuth, (req, res) => {
  const { key } = req.params;
  const { value } = req.body;
  if (value === undefined) {
    return res.status(400).json({ error: 'Campo "value" obrigatório' });
  }

  db.prepare(`
    INSERT INTO config (key, value, updated_at)
    VALUES (?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
  `).run(key, String(value));

  res.json({ ok: true, key, value });
});

// Apagar uma config
app.delete('/api/admin/config/:key', requireAdminAuth, (req, res) => {
  db.prepare('DELETE FROM config WHERE key = ?').run(req.params.key);
  res.json({ ok: true });
});

// ---------- ROTA QUE O APP ANDROID VAI CHAMAR ----------
// Não precisa de login, só da chave de app (x-api-key)
app.get('/api/app/config', requireAppKey, (req, res) => {
  const rows = db.prepare('SELECT key, value FROM config').all();
  const configObject = {};
  rows.forEach(r => { configObject[r.key] = r.value; });
  res.json(configObject);
});

// ---------- HISTÓRICO DE TESTES GERADOS NO SITE ----------

// Chamada pelo site principal (vltvplay-site) toda vez que um teste é
// gerado — autenticada com x-site-key (chave própria, separada da do app).
app.post('/api/admin/trials', requireSiteKey, (req, res) => {
  const { listId, listName, device, appLabel, username } = req.body;
  if (!listId || !device) {
    return res.status(400).json({ error: 'listId e device obrigatórios' });
  }
  db.prepare(`
    INSERT INTO trials (list_id, list_name, device, app_label, username)
    VALUES (?, ?, ?, ?, ?)
  `).run(listId, listName || '', device, appLabel || '', username || '');
  res.json({ ok: true });
});

// Lista o histórico de testes pro painel (protegida por login normal)
app.get('/api/admin/trials', requireAdminAuth, (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 100, 500);
  const rows = db.prepare('SELECT * FROM trials ORDER BY id DESC LIMIT ?').all(limit);
  res.json(rows);
});

// Licenças, aparelhos e parceiros (login obrigatório). Fica DEPOIS das rotas acima de propósito:
// o router exige login em tudo que passa por ele, então /login e /trials (chave do site) precisam vir antes.
app.use('/api/admin', license.adm);

// Healthcheck simples
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`VLTV Admin API rodando na porta ${PORT}`));
