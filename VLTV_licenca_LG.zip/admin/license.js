// Licenças do app da LG: teste grátis por TV + ativação anual.
// Rotas públicas (a TV chama):  /lg/register  /lg/status  /lg/config  /parceiro/resolver  /lg/pix/webhook
// Rotas do painel (login):      /api/admin/devices*  /api/admin/partners*  /api/admin/payments  /api/admin/lg-stats
const crypto = require('crypto');
const express = require('express');
const db = require('./db');
const { requireAdminAuth, limitar, igual } = require('./auth');

const TRIAL_DIAS = parseInt(process.env.TRIAL_DIAS || '7', 10);
const ANO_DIAS = 365;
const VITALICIO = 4102444800;   // 01/01/2100: licença sem vencimento
const ehVitalicio = d => d.paid_until >= VITALICIO;
const DIA = 86400;
const ALFABETO = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const agoraS = () => Math.floor(Date.now() / 1000);

function segredo() {
  if (!process.env.LICENSE_SECRET || process.env.LICENSE_SECRET.length < 24) {
    throw new Error('Defina LICENSE_SECRET (24+ caracteres) no .env do admin');
  }
  return process.env.LICENSE_SECRET;
}

// Token da TV: "device_id.expira.assinatura" (HMAC). Sem guardar nada no banco.
function assinar(deviceId, validadeDias) {
  const exp = agoraS() + validadeDias * DIA;
  const base = deviceId + '.' + exp;
  const sig = crypto.createHmac('sha256', segredo()).update(base).digest('base64url');
  return base + '.' + sig;
}
function verificar(token) {
  const p = String(token || '').split('.');
  if (p.length !== 3) return null;
  const base = p[0] + '.' + p[1];
  const sig = crypto.createHmac('sha256', segredo()).update(base).digest('base64url');
  if (!igual(sig, p[2])) return null;
  if (parseInt(p[1], 10) < agoraS()) return null;
  return p[0];
}

function gerarCodigo(tabela, coluna) {
  for (;;) {
    const b = crypto.randomBytes(8);
    let c = '';
    for (let i = 0; i < 8; i++) c += ALFABETO[b[i] % ALFABETO.length];
    if (!db.prepare(`SELECT 1 FROM ${tabela} WHERE ${coluna} = ?`).get(c)) return c;
  }
}

function estadoDe(d) {
  const t = agoraS();
  if (d.blocked) return 'blocked';
  if (d.paid_until > t) return 'active';
  if (d.trial_end > t) return 'trial';
  return 'expired';
}
function resposta(d, extra) {
  const estado = estadoDe(d);
  const fim = estado === 'active' ? d.paid_until : d.trial_end;
  return Object.assign({
    estado,
    vitalicio: ehVitalicio(d),
    codigo: d.code,
    expira_em: fim,
    dias: Math.max(0, Math.ceil((fim - agoraS()) / DIA)),
    pagar_url: process.env.PAGAR_URL || 'vltvplay.tech/ativar'
  }, extra || {});
}

function limpoId(v) { return String(v || '').trim().slice(0, 80); }
function limpoMac(v) {
  const m = String(v || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  return m.length === 12 && m !== '000000000000' && m !== 'FFFFFFFFFFFF' ? m : '';
}

const pub = express.Router();

// A TV se apresenta. Se for nova, ganha o teste; se já existe, só recebe o estado atual.
pub.post('/lg/register',
  limitar('reg', 30, 3600000),
  (req, res) => {
    const deviceId = limpoId(req.body.device_id);
    const mac = limpoMac(req.body.mac);
    if (!/^(mac|uid)-[A-Za-z0-9]{8,64}$/.test(deviceId)) {
      return res.status(400).json({ error: 'device_id inválido' });
    }
    const model = limpoId(req.body.model).slice(0, 60);
    const versao = limpoId(req.body.version).slice(0, 20);
    const t = agoraS();

    let d = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(deviceId);
    // Mesmo MAC com outro device_id (app reinstalado/limpo): é a mesma TV, não ganha outro teste.
    if (!d && mac) d = db.prepare('SELECT * FROM devices WHERE mac = ? ORDER BY id LIMIT 1').get(mac);

    if (!d) {
      // Freio contra criar testes em massa: no máximo 5 TVs novas por IP por dia.
      const hoje = db.prepare('SELECT COUNT(*) n FROM devices WHERE last_ip = ? AND created_at > ?').get(req.ip, t - DIA).n;
      if (hoje >= 5) return res.status(429).json({ error: 'Limite de novos aparelhos neste endereço. Tente amanhã.' });
      db.prepare(`INSERT INTO devices (device_id, code, mac, model, app_version, created_at, trial_end, last_seen, last_ip)
                  VALUES (?,?,?,?,?,?,?,?,?)`)
        .run(deviceId, gerarCodigo('devices', 'code'), mac || null, model, versao, t, t + TRIAL_DIAS * DIA, t, req.ip);
      d = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(deviceId);
    } else {
      db.prepare('UPDATE devices SET last_seen=?, last_ip=?, model=COALESCE(NULLIF(?,\'\'),model), app_version=COALESCE(NULLIF(?,\'\'),app_version), mac=COALESCE(mac, ?) WHERE id=?')
        .run(t, req.ip, model, versao, mac || null, d.id);
      d = db.prepare('SELECT * FROM devices WHERE id = ?').get(d.id);
    }
    res.json(resposta(d, { token: assinar(d.device_id, 60) }));
  });

// A TV pergunta o estado (a cada abertura e de tempos em tempos).
pub.get('/lg/status', limitar('st', 1200, 3600000), (req, res) => {
  const h = req.headers['authorization'] || '';
  const id = verificar(h.startsWith('Bearer ') ? h.slice(7) : '');
  if (!id) return res.status(401).json({ error: 'token' });
  const d = db.prepare('SELECT * FROM devices WHERE device_id = ?').get(id);
  if (!d) return res.status(404).json({ error: 'desconhecido' });
  db.prepare('UPDATE devices SET last_seen=?, last_ip=? WHERE id=?').run(agoraS(), req.ip, d.id);
  res.json(resposta(d, { token: assinar(d.device_id, 60) }));
});

// Visual e campanhas: só chaves "lg." da tabela config (cores, logo, banners, campanhas).
pub.get('/lg/config', limitar('cfg', 120, 3600000), (req, res) => {
  const rows = db.prepare("SELECT key, value FROM config WHERE key LIKE 'lg.%'").all();
  const o = {};
  rows.forEach(r => { o[r.key.slice(3)] = r.value; });
  res.set('Cache-Control', 'public, max-age=300').json(o);
});

// Código de parceiro -> lista de DNS (mesmo contrato do servidor antigo da porta 3355).
function limpoCodigo(t) { return String(t || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
pub.get('/parceiro/resolver', limitar('par', 20, 60000), (req, res) => {
  const codigo = limpoCodigo(req.query.codigo);
  const p = codigo && db.prepare('SELECT * FROM partners WHERE code = ?').get(codigo);
  res.set('Cache-Control', 'no-store');
  if (!p) return res.status(404).json({ ok: false });
  if (!p.active) return res.status(403).json({ ok: false });
  res.json({ ok: true, nome: p.name, dns: JSON.parse(p.dns) });
});

// ----- Pix: o provedor (Mercado Pago/Efí/Asaas) chama aqui quando o pagamento cai -----
// Fica atrás de PIX_WEBHOOK_SECRET (cabeçalho x-webhook-secret ou ?s=). O adaptador do provedor
// só precisa mandar { device_code, txid, amount_cents }. Idempotente por txid.
function ativar(codigo, meses, txid, valor, provedor) {
  const d = db.prepare('SELECT * FROM devices WHERE code = ?').get(limpoCodigo(codigo));
  if (!d) return { ok: false, motivo: 'codigo' };
  const t = agoraS();
  const tx = db.transaction(() => {
    if (txid) {
      const ja = db.prepare('SELECT 1 FROM payments WHERE txid = ?').get(txid);
      if (ja) return { ok: true, repetido: true };
      db.prepare('INSERT INTO payments (device_code, txid, amount_cents, provider, created_at) VALUES (?,?,?,?,?)')
        .run(d.code, txid, valor || null, provedor || 'manual', t);
    }
    if (meses === 'vitalicio') {
      db.prepare('UPDATE devices SET paid_until = ? WHERE id = ?').run(VITALICIO, d.id);
      return { ok: true };
    }
    if (ehVitalicio(d)) return { ok: true };   // já é vitalícia: não encurta
    const base = Math.max(t, d.paid_until);
    db.prepare('UPDATE devices SET paid_until = ? WHERE id = ?').run(base + Math.round(meses * ANO_DIAS / 12) * DIA, d.id);
    return { ok: true };
  });
  return tx();
}
pub.post('/lg/pix/webhook', limitar('pix', 120, 60000), (req, res) => {
  const s = req.headers['x-webhook-secret'] || req.query.s;
  if (!process.env.PIX_WEBHOOK_SECRET || !igual(s, process.env.PIX_WEBHOOK_SECRET)) return res.status(401).json({ error: 'x' });
  const { device_code, txid, amount_cents, plano } = req.body || {};
  if (!device_code || !txid) return res.status(400).json({ error: 'dados' });
  const r = ativar(device_code, plano === 'vitalicio' ? 'vitalicio' : 12, String(txid).slice(0, 80), parseInt(amount_cents, 10) || null, 'pix');
  res.status(r.ok ? 200 : 404).json(r);
});


// ============ PAGAMENTO PIX (Mercado Pago) ============
// O valor SEMPRE sai do servidor (config lg.valor_anual / lg.valor_vitalicio, em reais): o site só escolhe o plano.
// A liberação nunca confia no que chega no webhook: o servidor pergunta o pagamento direto ao Mercado Pago.
const MP_API = process.env.MP_API_URL || 'https://api.mercadopago.com';

function valorDoPlano(plano) {
  const chave = plano === 'vitalicio' ? 'lg.valor_vitalicio' : 'lg.valor_anual';
  const r = db.prepare('SELECT value FROM config WHERE key = ?').get(chave);
  const v = r ? parseFloat(String(r.value).replace(',', '.')) : NaN;
  return isFinite(v) && v >= 1 ? Math.round(v * 100) : 0;
}

pub.get('/lg/planos', limitar('planos', 120, 3600000), (req, res) => {
  res.set('Cache-Control', 'no-store').json({
    anual: valorDoPlano('anual') / 100,
    vitalicio: valorDoPlano('vitalicio') / 100,
    pix_ativo: !!process.env.MP_ACCESS_TOKEN
  });
});

// Situação da TV pelo código (para o site mostrar "pagamento confirmado"). Só devolve o essencial.
pub.get('/lg/ativacao', limitar('ativ', 240, 3600000), (req, res) => {
  const d = db.prepare('SELECT * FROM devices WHERE code = ?').get(limpoCodigo(req.query.codigo));
  if (!d) return res.status(404).json({ error: 'Código não encontrado. Confira o código na tela da TV.' });
  res.set('Cache-Control', 'no-store').json({ estado: estadoDe(d), vitalicio: ehVitalicio(d) });
});

// O site pergunta se ESTE pagamento (id devolvido por /lg/pagar) já foi confirmado.
pub.get('/lg/pix/:id', limitar('pixst', 600, 3600000), (req, res) => {
  const id = String(req.params.id).replace(/[^0-9]/g, '');
  const pago = !!db.prepare('SELECT 1 FROM payments WHERE txid = ?').get('mp-' + id);
  res.set('Cache-Control', 'no-store').json({ pago });
});

pub.post('/lg/pagar',
  limitar('pagar', 20, 3600000),
  limitar('pagar-cod', 8, 3600000, req => limpoCodigo((req.body || {}).codigo)),
  async (req, res) => {
    try {
      if (!process.env.MP_ACCESS_TOKEN) return res.status(503).json({ error: 'Pagamento indisponível no momento.' });
      const b = req.body || {};
      const d = db.prepare('SELECT * FROM devices WHERE code = ?').get(limpoCodigo(b.codigo));
      if (!d) return res.status(404).json({ error: 'Código não encontrado. Confira o código na tela da TV.' });
      if (d.blocked) return res.status(403).json({ error: 'Esta TV está bloqueada. Fale com o suporte.' });
      const plano = b.plano === 'vitalicio' ? 'vitalicio' : 'anual';
      if (ehVitalicio(d)) return res.status(409).json({ error: 'Esta TV já tem licença vitalícia.' });
      const cents = valorDoPlano(plano);
      if (!cents) return res.status(503).json({ error: 'Plano indisponível no momento.' });

      const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(b.email || '')) ? String(b.email).slice(0, 120) : 'cliente@vltvplay.tech';
      const resp = await fetch(MP_API + '/v1/payments', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + process.env.MP_ACCESS_TOKEN,
          'Content-Type': 'application/json',
          'X-Idempotency-Key': crypto.randomUUID()
        },
        body: JSON.stringify({
          transaction_amount: cents / 100,
          description: 'VLTV Play - licença ' + (plano === 'vitalicio' ? 'vitalícia' : 'anual') + ' - TV ' + d.code,
          payment_method_id: 'pix',
          payer: { email },
          external_reference: d.code + '|' + plano,
          notification_url: (process.env.PUBLIC_API_URL || 'https://api.vltvplay.tech') + '/lg/mp/webhook'
        })
      });
      const j = await resp.json().catch(() => ({}));
      const td = j && j.point_of_interaction && j.point_of_interaction.transaction_data;
      if (!resp.ok || !td || !td.qr_code) {
        console.error('[mp] erro ao criar pix', resp.status, JSON.stringify(j).slice(0, 400));
        return res.status(502).json({ error: 'Não foi possível gerar o Pix agora. Tente de novo em instantes.' });
      }
      db.prepare('INSERT OR REPLACE INTO pix_pending (mp_id, device_code, plano, amount_cents, created_at) VALUES (?,?,?,?,?)')
        .run(String(j.id), d.code, plano, cents, agoraS());
      res.json({ id: j.id, plano, valor: cents / 100, qr_code: td.qr_code, qr_code_base64: td.qr_code_base64 });
    } catch (e) {
      console.error('[mp] pagar', e);
      res.status(500).json({ error: 'Erro ao gerar o pagamento.' });
    }
  });

// O Mercado Pago avisa aqui (POST com { type:'payment', data:{ id } } ou ?type=payment&data.id=...).
pub.post('/lg/mp/webhook', limitar('mp', 300, 60000), async (req, res) => {
  res.status(200).json({ ok: true });    // responde rápido; o resto roda depois
  try {
    if (!process.env.MP_ACCESS_TOKEN) return;
    const body = req.body || {};
    const tipo = body.type || req.query.type || (body.action || '').split('.')[0];
    const id = String((body.data && body.data.id) || req.query['data.id'] || req.query.id || '').replace(/[^0-9]/g, '');
    if (tipo !== 'payment' || !id) return;
    const pend = db.prepare('SELECT * FROM pix_pending WHERE mp_id = ?').get(id);
    if (!pend) return;                    // só aceita pagamentos que o nosso servidor criou
    const r = await fetch(MP_API + '/v1/payments/' + id, { headers: { 'Authorization': 'Bearer ' + process.env.MP_ACCESS_TOKEN } });
    const p = await r.json().catch(() => ({}));
    if (!r.ok || p.status !== 'approved') return;
    if (Math.round(Number(p.transaction_amount) * 100) < pend.amount_cents) {
      console.error('[mp] valor menor que o esperado', id, p.transaction_amount, pend.amount_cents);
      return;
    }
    const out = ativar(pend.device_code, pend.plano === 'vitalicio' ? 'vitalicio' : 12, 'mp-' + id, pend.amount_cents, 'mercadopago');
    if (out && out.ok) db.prepare('DELETE FROM pix_pending WHERE mp_id = ?').run(id);
    console.log('[mp] pagamento aprovado', id, pend.device_code, pend.plano);
  } catch (e) {
    console.error('[mp] webhook', e);
  }
});

// ============ PAINEL (precisa de login) ============
const adm = express.Router();
adm.use(requireAdminAuth);

adm.get('/devices', (req, res) => {
  const q = String(req.query.q || '').trim();
  const lim = Math.min(parseInt(req.query.limit, 10) || 200, 1000);
  const t = agoraS();
  let sql = 'SELECT * FROM devices';
  const args = [];
  const w = [];
  if (q) { w.push('(code LIKE ? OR mac LIKE ? OR model LIKE ? OR note LIKE ? OR device_id LIKE ?)'); const l = '%' + q + '%'; args.push(l, l, l, l, l); }
  const e = req.query.estado;
  if (e === 'blocked') w.push('blocked = 1');
  else if (e === 'active') { w.push('blocked = 0 AND paid_until > ?'); args.push(t); }
  else if (e === 'trial') { w.push('blocked = 0 AND paid_until <= ? AND trial_end > ?'); args.push(t, t); }
  else if (e === 'expired') { w.push('blocked = 0 AND paid_until <= ? AND trial_end <= ?'); args.push(t, t); }
  if (w.length) sql += ' WHERE ' + w.join(' AND ');
  sql += ' ORDER BY id DESC LIMIT ?';
  args.push(lim);
  res.json(db.prepare(sql).all(...args).map(d => Object.assign({}, d, { estado: estadoDe(d) })));
});

adm.get('/lg-stats', (req, res) => {
  const t = agoraS();
  const n = (w, ...a) => db.prepare('SELECT COUNT(*) n FROM devices WHERE ' + w).get(...a).n;
  res.json({
    total: n('1=1'),
    ativos: n('blocked=0 AND paid_until > ?', t),
    teste: n('blocked=0 AND paid_until <= ? AND trial_end > ?', t, t),
    expirados: n('blocked=0 AND paid_until <= ? AND trial_end <= ?', t, t),
    bloqueados: n('blocked=1'),
    novos_24h: n('created_at > ?', t - DIA),
    pagamentos: db.prepare('SELECT COUNT(*) n FROM payments').get().n
  });
});

// Ações sobre uma TV (por id numérico ou código)
adm.patch('/devices/:ref', (req, res) => {
  const ref = req.params.ref;
  const d = /^\d+$/.test(ref) ? db.prepare('SELECT * FROM devices WHERE id=?').get(ref) : db.prepare('SELECT * FROM devices WHERE code=?').get(limpoCodigo(ref));
  if (!d) return res.status(404).json({ error: 'não encontrado' });
  const b = req.body || {};
  const t = agoraS();
  if (b.activate_lifetime) {
    ativar(d.code, 'vitalicio', 'admin-vit-' + t + '-' + d.id, null, 'manual:' + (req.admin.username || ''));
  }
  if (b.activate_months) {
    const m = Math.min(Math.max(parseFloat(b.activate_months), 0.1), 60);
    ativar(d.code, m, 'admin-' + t + '-' + d.id, null, 'manual:' + (req.admin.username || ''));
  }
  if (b.add_trial_days) {
    const dias = Math.min(Math.max(parseInt(b.add_trial_days, 10), 1), 365);
    db.prepare('UPDATE devices SET trial_end = ? WHERE id = ?').run(Math.max(t, d.trial_end) + dias * DIA, d.id);
  }
  if (b.revoke) db.prepare('UPDATE devices SET paid_until = 0, trial_end = ? WHERE id = ?').run(t - 1, d.id);
  if (b.blocked !== undefined) db.prepare('UPDATE devices SET blocked = ? WHERE id = ?').run(b.blocked ? 1 : 0, d.id);
  if (b.note !== undefined) db.prepare('UPDATE devices SET note = ? WHERE id = ?').run(String(b.note).slice(0, 200), d.id);
  const n = db.prepare('SELECT * FROM devices WHERE id=?').get(d.id);
  res.json(Object.assign({}, n, { estado: estadoDe(n) }));
});

adm.delete('/devices/:id', (req, res) => {
  db.prepare('DELETE FROM devices WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

adm.get('/payments', (req, res) => {
  res.json(db.prepare('SELECT * FROM payments ORDER BY id DESC LIMIT 300').all());
});

// ----- Parceiros -----
function limpoDns(lista) {
  const out = [];
  (Array.isArray(lista) ? lista : String(lista || '').split(/[\s,;]+/)).forEach(i => {
    let u = String(i || '').trim();
    if (!u) return;
    if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
    u = u.replace(/\/+$/, '');
    if (out.indexOf(u) === -1) out.push(u);
  });
  return out;
}
adm.get('/partners', (req, res) => {
  res.json(db.prepare('SELECT * FROM partners ORDER BY created_at DESC').all().map(p => Object.assign({}, p, { dns: JSON.parse(p.dns) })));
});
adm.post('/partners', (req, res) => {
  const nome = String((req.body || {}).name || '').trim().slice(0, 80);
  const dns = limpoDns((req.body || {}).dns);
  if (!nome || !dns.length) return res.status(400).json({ error: 'name e dns obrigatórios' });
  const code = gerarCodigo('partners', 'code');
  db.prepare('INSERT INTO partners (code, name, dns, active, created_at) VALUES (?,?,?,1,?)').run(code, nome, JSON.stringify(dns), agoraS());
  res.json({ ok: true, code });
});
adm.patch('/partners/:code', (req, res) => {
  const p = db.prepare('SELECT * FROM partners WHERE code = ?').get(limpoCodigo(req.params.code));
  if (!p) return res.status(404).json({ error: 'não encontrado' });
  const b = req.body || {};
  const nome = b.name !== undefined ? String(b.name).trim().slice(0, 80) : p.name;
  const dns = b.dns !== undefined ? limpoDns(b.dns) : JSON.parse(p.dns);
  if (!nome || !dns.length) return res.status(400).json({ error: 'dados inválidos' });
  db.prepare('UPDATE partners SET name=?, dns=?, active=? WHERE code=?').run(nome, JSON.stringify(dns), b.active === undefined ? p.active : (b.active ? 1 : 0), p.code);
  res.json({ ok: true });
});
adm.delete('/partners/:code', (req, res) => {
  db.prepare('DELETE FROM partners WHERE code = ?').run(limpoCodigo(req.params.code));
  res.json({ ok: true });
});

module.exports = { pub, adm, estadoDe };
